export const environment = {
  production: true,
  baseApiURL: 'https://api.themoviedb.org/3/',
  baseImageURL: 'https://image.tmdb.org/t/p/',
};
