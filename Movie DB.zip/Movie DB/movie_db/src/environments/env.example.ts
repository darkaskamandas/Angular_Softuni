export const myEnv = {
  baseApiURL: '',
  baseImageURL: '',
  apiKey: ''
};
