# Moviedb
# angular-movie-db

Installation
---
1. Clone the Repository

        $ git clone git@github.com:kburudi/angular-movie-db.git
        
2. checkout the directory and Install Dependencies

        $ cd angular-movie-db

        $ yarn || npm install
        
3. check your src/environments folder
    - rename emv.example.ts to env.ts
    - replace the variables with your exact variable names
    - save the file and your good to go

4. start the server

        $ ng serve

5. run tests

        $ ng test
