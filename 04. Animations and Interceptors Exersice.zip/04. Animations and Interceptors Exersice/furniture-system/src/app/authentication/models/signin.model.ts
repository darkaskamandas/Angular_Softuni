export class SignInModel {
  constructor(
    public email : string,
    public password : string
  ) { }
}