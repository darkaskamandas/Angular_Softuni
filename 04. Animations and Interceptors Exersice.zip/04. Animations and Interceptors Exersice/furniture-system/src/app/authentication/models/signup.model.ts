export class SignUpModel {
  constructor(
    public email : string,
    public password : string,
    public name : string
  ) { }
}